package Interfaces;

public interface IMenu {

    void SetMenu();

    void ShowMenu();
}
